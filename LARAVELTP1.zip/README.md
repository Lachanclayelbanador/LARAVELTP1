# LARAVELTP1
J'ai passé un temps astronomique sur le projet et malgré cela je n'ai pas pu passer les 10 derniers tests car je ne comprends pas toujours leur fonctionnement,
Ou bien des fois j'ai un code similaire à celui d'un camarade qui passe un test x, et pour moi rien ne marche,
Je m'en excuse donc d'avance.

Bien à vous,
Léo.
